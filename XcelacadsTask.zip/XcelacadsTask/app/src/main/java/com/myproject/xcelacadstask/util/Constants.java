package com.myproject.xcelacadstask.util;

public class Constants {

    public static final String BASE_URL = "https://www.googleapis.com/youtube/v3/";
    public static final String KEY = "AIzaSyDcFYPzyxVPlOE0VEzKKm1VHnZOAiLhAPE";
    public static final String max = "10";
}
